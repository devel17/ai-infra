package org.example;

public interface IMap<V,K> {
    void put(K key, V value);
    V get(K key);
    boolean remove(K key);
    int size();
    boolean isEmpty();
}
