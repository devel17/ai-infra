package org.example;

public class QuickSort implements Sortable {

    @Override
    public int[] sort(int[] arr) {
        if (arr == null || arr.length == 0) return null;
        return sort(arr, 0, arr.length - 1);
    }

    private int[] sort(int[] arr, int left, int right) {
        if (left >= right) return arr;
        final int pivot = arr[right];
        int swapPos = left;

        for (int i = left; i < right; i++) {
            if (arr[i] <= pivot) {
                swap(arr, swapPos, i);
                swapPos++;
            }
        }
        swap(arr, swapPos, right);
        sort(arr, left, swapPos - 1);
        sort(arr, swapPos + 1, right);
        return arr;
    }

    private void swap(int[] arr, int first, int second) {
        if (first == second) return;
        final int tmp = arr[first];
        arr[first] = arr[second];
        arr[second] = tmp;
    }


}
