package org.example;

public class CustomHashMap<K,V> implements IMap<K,V> {

    public static final int DEFAULT_HASHMAP_CAPACITY = 1<<4;
    public static final double LOAD_FACTOR = 0.75;
    public static final int THRESHOLD_TO_TREE = 8;
    public static final int THRESHOLD_TO_LIST = 6;
    private int capacity = DEFAULT_HASHMAP_CAPACITY;
    private int threshold = (int) (DEFAULT_HASHMAP_CAPACITY * LOAD_FACTOR);
    public int size;
    public Node<K,V>[] table =  new Node[DEFAULT_HASHMAP_CAPACITY];

    private static class Node<K,V> {
        private K key;
        private V val;
        private final int hash;
        private Node next;

        public Node(K key,V value, Node next, int hash) {
            this.key = key;
            this.val = value;
            this.next = next;
            this.hash = hash;
        }
    }

    @Override
    public void put(Object key, Object value) {
        final int h = hash(key);
        final int i = getIndex(h , capacity);
        if (table[i] == null) {
            size++;
            table[i] = new Node(key, value, null,h);
        } else {
            //collision
            Node firstNode = table[i];
            if (key == firstNode.key || key.equals(firstNode.key)) {
                //same link or same key : replace
                firstNode.val = value;
            } else {
                //diffrent keys :
                Node nodeForUpdate = searchNodeByKey(key, firstNode);
                if (nodeForUpdate == null) {
                    size++;
                    table[i] = new Node(key, value, firstNode,h);
                } else {
                    nodeForUpdate.val = value;
                }
            }
        }
        if (size > threshold) resize();
    }
     private Node<K,V> searchNodeByKey(Object key, Node<K,V> n) {
        if (n.next == null) return null;//tail
        if (n.next.key == key || n.next.key.equals(key)) {
            return  n.next;
        } else {
            return searchNodeByKey(key, n.next);
        }
     }

    @Override
    public Object get(Object key) {
        final int h = hash(key);
        final int i = getIndex(h , capacity);
        Node firstNode = table[i];
        if (key == firstNode.key || key.equals(firstNode.key)) {
            return firstNode.val;
        } else {
            Node node = searchNodeByKey(key, firstNode);
            if (node != null) return node.val;
        }
        return null;
    }

    @Override
    public boolean remove(Object key) {
        final int i = getIndex(hash(key) , capacity);
        if (table[i] == null) {
            return false;
        } else {
            if (key == table[i].key || key.equals(table[i].key)) {
                size--;
                table[i] = table[i].next ;
                return true;
            } else {
                return deleteNodeByKey(key, table[i]);
            }
        }
    }

    private boolean deleteNodeByKey(Object key, Node<K,V> n) {
        if (n.next == null) return false;//tail
        if (n.next.key == key || n.next.key.equals(key)) {
            size--;
            n.next = n.next.next;
            return true;
        } else {
            return deleteNodeByKey(key, n.next);
        }
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean  isEmpty() {
        return size == 0;
    }

    static final int hash(Object key) {
        int hash = key.hashCode();
        return key == null ? 0 : hash ^ (hash >>>16);
    };

    public String stat() {
        StringBuilder nodesStat = new StringBuilder();
        StringBuilder elemStat = new StringBuilder();
        for (int i = 0; i < table.length; i++) {
            if(table[i] == null) continue;
            nodesStat.append(i + ":" + countNodeElements(table[i]) + ";");
            elemStat.append(pringNodeElements(table[i]));
        }

        return nodesStat.toString() + " <-----:-----> " + elemStat.toString();
    };

    private int countNodeElements(Node n) {
        if (n != null && n.key!= null) return 1 + countNodeElements(n.next);
       return 0;
    }
    private String pringNodeElements(Node n) {
        if (n != null && n.key!= null) return
                new StringBuilder().append(n.key + ":" + n.val + ";" + pringNodeElements(n.next)).toString();
        return "";
    }


    private void resize() {
        System.out.println("RESIZE!");
        capacity <<=1;
        threshold = (int) (capacity*LOAD_FACTOR);
        final Node[] old = this.table;
        //rehash
        Node[] newTable = new Node[capacity];
        for (int i = 0; i < old.length; i++) {
            if (old[i] == null) continue;
            int index = getIndex(old[i].hash, capacity);
            newTable[index] = old[i];
            table = newTable;
        }
    }

    private int getIndex(int hash, int capacity ) {
        return hash & (capacity - 1);
    }

    public static void main(String[] args) {
        CustomHashMap<String,String> map = new CustomHashMap<String,String>();
        map.put("nastya","kurilenko");
        map.put("nastya","rovkach");
        map.put("igor","rovkach");
        map.put("grigory","rovkach");
        map.put("1","1");
        map.put("2","2");
        map.put("3","3");
        map.put("4","4");
        map.put("5","5");
        map.put("6","6");
        map.put("7","7");
        map.put("8","8");
        map.put("9","9");
        map.put("10","10");
        map.put("11","11");
        map.put("12","12");
        map.put("13","13");
        System.out.println(map.stat());
        map.put("14","14");
        map.put("15","15");
        map.put("16","16");
        map.put("17","17");
        map.put("18","18");
        map.put("18","18");
        map.put("20","20");
        map.put("21","21");
        map.put("22","22");
        map.put("23","23");
        map.put("24","24");
        map.put("25","25");
        map.put("26","26");
        map.put("27","27");
        map.put("28","28");
        map.put("29","29");
        map.put("30","30");
        System.out.println(map.stat());
        map.put("31","31");
//        System.out.println(map.get("nastya"));
        System.out.println(map.size());

//        System.out.println(map.remove("grigory"));
//        System.out.println(map.remove("10"));
        System.out.println(map.stat());
        System.out.println(map.size());
    }
}
