package org.example;

public class CustomLinkedList<T> implements ILinkedList<T> {


    private int size;
    private Node<T> head;
    private Node<T> tail;

    private static class Node<T> {
        T val;
        Node<T> next;
        Node<T> prev;

        public Node(Node<T> next, Node<T> prev, T val) {
            this.next = next;
            this.prev = prev;
            this.val = val;
        }
        public Node(T val) {
            this.val = val;
        }
    }

    @Override
    public void addFirst(T object) {
        final Node<T> newHead;
        Node<T> oldHead = head;
        if (size == 0 || oldHead == null) {
            newHead = new Node<T>(object);
            tail = newHead;
        } else {
            newHead = new Node<T>(oldHead, null, object);
            oldHead.prev = newHead;
        }
        head = newHead;
        size++;
    }

    @Override
    public void addLast(T object) {
        final Node<T> newTail;
        Node<T> oldTail = tail;
        if (size == 0 || oldTail == null) {
            newTail = new Node<T>(object);
            head = newTail;
        } else {
            newTail = new Node<T>(null, oldTail, object);
            oldTail.next = newTail;
        }
        tail = newTail;
        size++;
    }

    @Override
    public void add(int index, T object) {

    }

    @Override
    public boolean deleteFirst() {
        if (size == 0) return false;
        Node<T> oldHead = head;
        Node<T> newHead = head.next;
        oldHead = null;
        newHead.prev = null;
        head = newHead;
        size--;
        return true;
    }

    @Override
    public boolean deleteLast() {
        if (size == 0) return false;
        Node<T> oldTail = tail;
        Node<T> newTail = tail.prev;
        oldTail = null;
        newTail.next = null;
        tail = newTail;
        size--;
        return true;
    }

    @Override
    public boolean delete(int index, T object) {
        return false;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    public String getStrHead(Node n) {
        StringBuilder rez = new StringBuilder();
        rez.append(n.val).append(" ");
        if (n.next != null) {
            rez.append(getStrHead(n.next));
        }
        return rez.toString();
    }

    public String getStrTail(Node n) {
        StringBuilder rez = new StringBuilder();
        rez.append(n.val).append(" ");
        if (n.prev != null) {
            rez.append(getStrTail(n.prev));
        }
        return rez.toString();
    }

    public static void main(String[] args) {
        CustomLinkedList<Integer> list = new CustomLinkedList<Integer>();
        list.addFirst(0);
        list.addFirst(1);
        list.addFirst(4);
        list.addLast(3);
        list.addLast(2);
        list.addLast(1);
        System.out.println(list.getStrHead(list.head));
        System.out.println(list.getStrTail(list.tail));
        System.out.println(list.size());

        list.deleteFirst();
        list.deleteLast();
        System.out.println(list.getStrHead(list.head));
        System.out.println(list.getStrTail(list.tail));
        System.out.println(list.size());

        list.deleteLast();
        list.deleteLast();
        list.deleteLast();
        System.out.println(list.getStrHead(list.head));
        System.out.println(list.getStrTail(list.tail));
        System.out.println(list.size());


    }
}
