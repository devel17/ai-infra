package org.example;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * {{2, 8}, {1, 10}} | {{1, 10} , {2, 8}}
 * { {1, 2} , {3, 4}};
 */
public class IntervalMerger {
    public static int[][] merge(int[][] matrix) {
        if (matrix == null || matrix.length < 1) return new int[][]{};

        System.out.println(Arrays.deepToString(matrix));
        Comparator<int[]> comparator = (o1, o2) -> Integer.compare(o1[0], o2[0]);
        Arrays.sort(matrix, Comparator.comparingInt(row -> row[0]));
        int[][] rez = new int[][]{{}};
        System.out.println(Arrays.toString(rez));


        rez[0] = matrix[0];
        int[] lastAppended = rez[0];
        for (int i = 1; i < matrix.length; i++) {
            if (matrix[i][0] < lastAppended[1]) {
                lastAppended[1] = lastAppended[1];
            } else {
                rez[i] = matrix[i];
            }
        }
        System.out.println(Arrays.deepToString(matrix));
        System.out.println(Arrays.deepToString(rez));


        return rez;
    }

//    public static List<List<Integer>> merge(List<List<Integer>> list) {
//        return list;
//    }

}
