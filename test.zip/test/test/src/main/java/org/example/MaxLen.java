package org.example;

public class MaxLen {

    public static int getMax(int[] arr) {
        int maxLen = 0;
        int currLen = 0;
        if (arr.length == 0) return 0;
        for (int i=0; i< arr.length;i++) {
            if (arr[i] == 1) {
                currLen++;
            } else {
                currLen = 0;
                if (maxLen > arr.length - i) return maxLen;

            }
            maxLen = Math.max(maxLen, currLen);

        }
        return maxLen;
    }
}
