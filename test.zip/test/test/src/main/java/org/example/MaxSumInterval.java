package org.example;

import java.util.Arrays;
import java.util.Comparator;

/**
 *
 * {-1 , 2 }
 *
 *
 */

public class MaxSumInterval {
    public static int calc(Integer[] arr) {
        if (arr == null || arr.length < 1) return 0;
        int sumAll = 0;
        int negativeCount = 0;
        for (Integer integer : arr) {
            sumAll += Math.abs(integer);
            if (integer < 0) {
                negativeCount++;
            }
        }
        System.out.println(sumAll);
        Arrays.sort(arr, Comparator.comparingInt(Math::abs));
        System.out.println(Arrays.toString(arr));
        int sumNegative = 0;
        for (int i = 0; i < negativeCount; i++) {
            sumNegative += Math.abs(arr[i]);
        }
        System.out.println(sumNegative);
        return sumAll - 2 * sumNegative;
    }
}
