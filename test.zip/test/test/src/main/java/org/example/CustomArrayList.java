package org.example;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;

public class CustomArrayList<T> implements IArrayList<T> {

    public static final Object[] DEFAULT_EMPTY_DATA = {};
    private T[] data;
    private int size;

    CustomArrayList() {
        this.data =  (T[]) DEFAULT_EMPTY_DATA;
    }

    @Override
    public void add(T object) {
        if (data.length == size) {
            data = Arrays.copyOf(data, size+1);
            data[size++] = object;
        }

    }

    @Override
    public T get(int index) {
        final T[] d = data;
        if (size == 0 || index > size) {
            throw new NoSuchElementException();
        }
        if (index < size) {
            return d[index];
        }
        return null;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public boolean isEmpty() {
        return size == 0 ;
    }

    @Override
    public boolean remove(int index) {
        final T[] d = data;
        if (size == 0 || index > size) {
            return false;
        }
        if (index < size) {
            System.arraycopy(d, index+1, d , index, size - index - 1);
            d[--size] = null;
            return true;
        }
        return false;
    }

    public Iterator<T> iterator() {
        return new Iterator<T>() {
            int cursor;

            @Override
            public boolean hasNext() {

                return cursor < size;
            }

            @Override
            public T next() {
                final T[] d = data;
                if (hasNext()) {
                    return d[cursor++];
                }
                return null;
            }
        };
    }

    public static void main(String[] args) {
        CustomArrayList<Integer> list = new CustomArrayList<Integer>();
        System.out.println(list.isEmpty());
        list.add(0);
        System.out.println(list.size());
        list.add(1);
        list.add(2);
        list.add(3);
        System.out.println(list.size());
        System.out.println(list.isEmpty());
        System.out.println(list.get(0));
        System.out.println(list.get(1));
//        System.out.println(list.get(2));

        System.out.println(list.remove(0));
        System.out.println(list.get(0));
        System.out.println(list.size());
        System.out.println("----------------");
       Iterator<Integer> it = list.iterator();
        while(it.hasNext()) {
            System.out.println(it.next());
       }

    }


}
