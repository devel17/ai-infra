package org.example;

public interface IArrayList<T> {
    void add(T object);
    T get(int index);
    boolean remove(int index);
    int size();
    boolean isEmpty();

}
