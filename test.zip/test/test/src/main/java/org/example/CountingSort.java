package org.example;

import java.util.Arrays;

public class CountingSort implements Sortable {
    @Override
    public int[] sort(int[] arr) {
        if (arr == null || arr.length <= 1) return arr;
        System.out.println(Arrays.toString(arr));

        int max = 0;
        for (int i = 0; i < arr.length; i++) {
            max = Math.max(max, arr[i]);
        }
        System.out.println("max:" + max);
        int[] counts = new int[max + 1];
        System.out.println("counts size:" + counts.length);
        for (int i = 0; i < arr.length; i++) {
            counts[arr[i]]++;
        }

        System.out.println(Arrays.toString(counts));
        for (int i = 1; i < counts.length; i++) {
            counts[i] = counts[i] + counts[i - 1];
        }

        System.out.println(Arrays.toString(counts));
        int k = 0;
        for (int i = 0; i < counts.length; i++) {
//            for (int j = 0; j < counts[i]; j++) {
            arr[k] = i;
            k += 1;
//            }
        }
        System.out.println(Arrays.toString(arr));
        return arr;
    }
}
