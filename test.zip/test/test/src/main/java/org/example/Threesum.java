package org.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Threesum {
    public static void main(String[] args) {
        int[] arr = new int[]{-7, 4, -3, 2, 7, -1, 3, -4, 0};
        List<List<Integer>> rez = new ArrayList<List<Integer>>();
        Arrays.sort(arr);
        int operationCount = 0;
        for (int i = 0; i < arr.length - 2; i++) {
            int left = i + 1;
            int right = arr.length - 1;
            while (left < right) {
                int s = arr[i] + arr[left] + arr[right];
                if (s > 0) {
                    right--;
                } else if (s < 0) {
                    left++;
                } else {
                    List<Integer> triple = new ArrayList<>();
                    triple.add(arr[i]);
                    triple.add(arr[left]);
                    triple.add(arr[right]);
                    rez.add(triple);
                    left++;

                }
                operationCount++;
//                if (operationCount == 1) break;
            }
        }

        System.out.println(Arrays.toString(arr));
        System.out.println(operationCount);
        System.out.println(rez);


    }
}
