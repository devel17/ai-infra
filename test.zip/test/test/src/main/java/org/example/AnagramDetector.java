package org.example;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class AnagramDetector {
    public static boolean isAnagram(String a, String b) {
        if (a == null || b == null || a.equals("") || b.equals("")) return false;
        Map map2 = Stream.of(a.toCharArray()).peek(System.out::println).collect(Collectors.groupingBy(
                it -> it,
                HashMap::new,
                Collectors.counting()
        ));
        Map<Integer,Long> map1 =  a.chars().boxed().collect(Collectors.groupingBy(it->it , HashMap::new, Collectors.counting()));
        System.out.println(map1);
        Map<Character, Integer> map = new HashMap<Character, Integer>();
//        for ( char c : a.toCharArray() ) {
//            map.merge(c, 1, (s1,s2) -> s1+s2);
//        }
        for ( char c : b.toCharArray() ) {
            if (map.get(c) != null) {
                map.put(c, (Integer)map.get(c)-1);
            } else {
               return false;
            }
        }
//        int summaryCount = 0;
//        for (int count : map.values()) {
//            summaryCount +=count;
//        }
//        if (summaryCount == 0) return true;
        return map.values().stream().reduce(0, Integer::sum) == 0 ? true: false;
//        return false;
    }

}
