package org.example;

import java.util.Arrays;

public class MergeSort implements Sortable {

    @Override
    public int[] sort(int[] arr) {
        System.out.println("ARR: " + Arrays.toString(arr));
        if (arr == null || arr.length <= 1) return arr;
        int mid = (arr.length - 1) / 2;
        System.out.println("MID:" + mid);

        int[] left = new int[mid + 1];
        int[] right = new int[arr.length - mid - 1];

        System.arraycopy(arr, 0, left, 0, mid + 1);
        System.arraycopy(arr, mid + 1, right, 0, arr.length - 1 - mid);

        System.out.println(Arrays.toString(left));
        System.out.println(Arrays.toString(right));
        sort(left);
        sort(right);

        return merge(arr, left, right);
    }

    private int[] merge(int[] arr, int[] left, int[] right) {
        int i = 0;
        int j = 0;
        int k = 0;
        while (i < left.length && j < right.length) {
            if (left[i] < right[j]) {
                arr[k++] = left[i++];
            } else {
                arr[k++] = right[j++];
            }
        }
        while (i < left.length) {
            arr[k++] = left[i++];
        }

        while (j < right.length) {
            arr[k++] = right[j++];
        }

        System.out.println(Arrays.toString(arr));
        return arr;
    }


}
