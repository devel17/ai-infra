package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Test {

    // map by given name
    public Map<String, Long> mapIdToName(List<Person> persons, String name) {
//        return persons.
//                stream().
//                filter(person -> person.name.equals(name)).
//                collect(Collectors.toMap(Person::id, Function.identity()));
        return persons.stream().collect(Collectors.groupingBy(Person::name, Collectors.counting()));
    }


    public static class Person {
        Long id;
        String name;

        public String name() {
            return this.name;
        }

        public Long id() {
            return this.id;
        }

        public Person(Long id, String name) {
            this.id = id;
            this.name = name;
        }

        @Override
        public String toString() {
            return id + " : " + name;
        }
    }


    public static void main(String[] args) {
        List<Person> list = new ArrayList<Person>();
        list.add(new Person(1l, "11111"));
        list.add(new Person(2l, "22222"));
        list.add(new Person(3l, "11111"));

        System.out.println(new Test().mapIdToName(list, "1"));

    }
}
