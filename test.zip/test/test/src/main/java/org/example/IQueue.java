package org.example;

public interface IQueue<T> {
    void put(T val);
    T take();
}
