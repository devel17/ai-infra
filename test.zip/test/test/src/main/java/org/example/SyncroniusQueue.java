package org.example;

public class SyncroniusQueue<T> implements IQueue {

    private static class Node<T> {

    }

    @Override
    public void put(Object val) {

    }

    @Override
    public Object take() {
        return null;
    }
}
