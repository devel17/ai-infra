package org.example;

import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.locks.ReentrantLock;
import java.util.function.IntPredicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;


/***
 * Развернуть мап ключи поменять местами со значениями
 */
public class ReverseMap {
//    ForkJoinPool
    HashMap map = new HashMap();
    public static void main(String[] args) {
      //# revers number
        int number = 12345;
        int reversed = 0;
//        String numStr = String.valueOf(number);
//        for (int i = 0 ; i < numStr.length(); i++) {
//            numStr
//        }

        while (number != 0) {
            int digit = number % 10;
            System.out.println(digit);
            reversed = reversed * 10 + digit;
            System.out.println(reversed);
            number /= 10;
            System.out.println(number);
            System.out.println();
        }
        System.out.println(reversed);
        //#8 binary search
//        /**
//         *
//         *Дан отсортированный по возрастанию массив целых чисел nums и целое число target.
//         * Нужно вернуть индекс target, если он есть в массиве, иначе -1.
//         *
//         * */
//
////        int[] nums = {-1,0,3,5,9,12,13};
////        int[] nums = {0,1,2,3,4,5,6};
////        int iteration = 0;
////        int target = 4;
////        int start = 0;
////        int end = nums.length;
////        int indx = 0;
////
////        while (start <= end  && iteration < 3) {
////            indx = (end-start)/2;
////            System.out.println(start + " " + end + "   " + indx + "->" + nums[indx] );
////            if (target == nums[indx]){
////                break;
////            }
////            start = indx;
////            iteration++;
////
////        }
////        System.out.println(indx);
        //№7

        /**
         * Условие:
         * Найти длину самой длинной подстроки без повторяющихся символов.
         *
         * Вход: s = "abcabcbb"
         * Выход: 3
         * Пояснение: "abc" - длина 3
         * */

//        String s = "abcabcbb";
//        int operationCount = 0;
//        int maxLen = 0;
//        int left = 0;
//
//        Set<Character> phrase = new HashSet();
//        for (int right = 0; right < s.length(); right++) {
//            while (phrase.contains(s.charAt(right))) {
//                phrase.remove(s.charAt(left));
//                left++;
//            }
//            operationCount++;
//            phrase.add(s.charAt(right));
//            maxLen = Math.max(maxLen, right - left + 1);
//            System.out.println(phrase.toString());
//        }
//        System.out.println(maxLen);
//        System.out.println(operationCount);

        //#6
/**
 *
 * Вход: nums = [1,1,1,2,2,3], k = 2
 * Выход: [1,2]
 * Пояснение: 1 встречается 3 раза, 2 встречается 2 раза, 3 встречается 1 раз.
 * Топ-2: 1 и 2*/

//        int[] nums = {1,2,3,4,5,6,7,8,9,10};
//        int k =3 ;
//
//         Arrays.stream(nums)
//                .boxed()
//                .collect(Collectors.groupingBy(it -> it , Collectors.counting()))
//                .entrySet()
//                .stream()
//                //.filter(it-> it.getValue() >= k)
//                 .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
//                 .limit(k)
//                .mapToInt(Map.Entry::getKey)
//                 .forEach(System.out::println);
        //.toArray();


        //.forEach(it -> System.out.println(it.getKey() + ":" + it.getValue()));


        //№5
//        String s = "Aabb"; //вывести отсортированными по частоте bbAa
//
//        String rez = s.chars()
//                .mapToObj(c -> (char) c)
//                .collect(Collectors.groupingBy(
//                        it -> it,
//                        HashMap::new,
//                        Collectors.counting()
//                ))
//                .entrySet()
//                .stream()
//                .sorted(Map.Entry.comparingByValue(Comparator.reverseOrder()))
//                .map(it -> String.valueOf((char)it.getKey()).repeat(it.getValue().intValue()))
//                .collect(Collectors.joining());
//        System.out.println(rez);
//                .forEach(it -> System.out.println(it.getKey() + ":" + it.getValue()));

////№4
//        String[] strs = {"eat","tea","tan","ate","nat","bat"};
//        //Выход: [["bat"],["nat","tan"],["ate","eat","tea"]]
//        System.out.println(
//                Arrays.stream(strs)
//                        .collect(Collectors.groupingBy(
//                                s -> {
//                                    char[] chars = s.toCharArray();
//                                    Arrays.sort(chars);
//                                    return new String(chars);
//                                },
//                                HashMap::new,
//                                Collectors.toList()
//                        ))
//                        .values()
//                        .stream()
//                        .collect(Collectors.toList())
//        );


        //#3 четные больше нуля более 2 раз среднее арифм
        List<Integer> nums1 = List.of(2, 4, 2, 6, 3, 4, 8);
//        List<Integer> nums1 = List.of(1,3,5,-2,-4);

        //Arrays.stream(nums1)
//        System.out.println(
//                nums1.stream()
//                        .filter(it -> it > 0)
//                        .filter(it -> it % 2 == 0)
//                        .collect(Collectors.groupingBy(it -> it, Collectors.counting()))
//                        .entrySet()
//                        .stream()
//                        .filter(it -> it.getValue() == 2)
//                        .mapToInt(Map.Entry::getKey)
//                        .average().orElse(0)
//                        .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue))


//        );

        //#1
//        Map<Integer, List<Long>> map = new HashMap<>();
//        map.put(1 , Arrays.asList(0L,1L,2L));
//        map.put(2, Arrays.asList(3L,4L));
//        map.entrySet().stream().map(it -> it.getValue().stream()
//                .map(it1 -> new HashMap.SimpleEntry<>(it1,it.getKey()))
//                .collect(Collectors.toMap( Map.Entry::getKey,  Map.Entry::getValue)))
//                .flatMap(it2 -> it2.entrySet().stream())
//                //.peek(it -> System.out.println(it))
//                .collect(Collectors.toMap(
//                        Map.Entry::getKey,
//                        Map.Entry::getValue  // берем последнее значение
//                ))

        //.entrySet().stream().forEach(System.out::println)
        ;

//#2 Вход: nums = [1,2,1]
//Выход: [1,2,1,1,2,1] конкатенация массива с собой

//        int[] nums = {1, 2, 3};
//        System.out.println(
//                Arrays.stream(IntStream.concat(IntStream.of(nums), IntStream.of(nums)).toArray()).toArray()[6]
//        );


    }
}
