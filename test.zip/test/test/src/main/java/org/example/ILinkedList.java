package org.example;

public interface ILinkedList<T> {
    void addFirst(T object);
    void addLast(T object);
    void add(int index, T object);
    boolean deleteFirst();
    boolean deleteLast();
    boolean delete(int index, T object);
    int size();
    boolean isEmpty();
}
