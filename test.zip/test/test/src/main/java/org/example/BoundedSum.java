package org.example;

import java.util.ArrayList;
import java.util.List;

public class BoundedSum {

    private List<Integer> list = new ArrayList<Integer>();
    private final int capacity = 10;
    private int sum;

    public synchronized void add(int value) throws InterruptedException {
        while (list.size() == capacity) {
            System.out.println("fully...");
            wait();
        }
        list.add(value);
        sum += value;
        notifyAll();
    }


    synchronized int getSumAndClear() throws InterruptedException {
        while (list.isEmpty()) {
            System.out.println("empty...");
            wait();
        }
        int result = sum;
        list.clear();
        sum = 0;
        notifyAll();
        return result;
    }

}
