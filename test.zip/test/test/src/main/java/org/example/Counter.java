package org.example;

import java.util.concurrent.atomic.AtomicInteger;

public class Counter {
    private AtomicInteger count = new AtomicInteger(0);

    public void increment() {
        count.updateAndGet(it -> it < 100 ? it + 1 : it);
    }

    public int getCount() {
        return count.get();
    }
}
