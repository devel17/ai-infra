package org.example;

public interface Sortable {
    int[] sort(int[] arr);
}
