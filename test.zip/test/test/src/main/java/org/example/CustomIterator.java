package org.example;

import java.util.Iterator;
import java.util.List;
import java.util.Spliterators;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public class CustomIterator<T> {

    public static <T> Stream<T> merge(Iterator<T> it1, Iterator<T> it2) {
        Stream<T> st1 = StreamSupport.stream(Spliterators.spliteratorUnknownSize(it1, 0), false);
        Stream<T> st2 = StreamSupport.stream(Spliterators.spliteratorUnknownSize(it2, 0), false);


        return Stream.concat(st1, st2);
    }


    public static void main(String[] args) {
        Iterator<Integer> it1 = List.of(1, 2, 3).iterator();
        Iterator<Integer> it2 = List.of(4, 5, 6).iterator();

        Stream<Integer> stream = CustomIterator.merge(it1, it2);
        System.out.println(stream.getClass().getName().compareTo(it1.getClass().getName()));
        System.out.println(System.identityHashCode(stream));
        System.out.println(System.identityHashCode(it1));
        //stream.forEach(System.out::println);
    }
}
