package org.example;

import java.util.Arrays;
import java.util.List;

/**
 * 0     1     2
 * l
 * {9,   9,    4}
 * r
 * 0     1     2
 */
public class FirstUniq {
    public static int getFirst(int[] arr) {
        if (arr == null || arr.length < 1) return 0;
        int left = 0;
        int right = 1;
        while (left < arr.length - 1) {
            if (arr[left] == arr[right]) {
                if (right == arr.length - 1) {
                    left++;
                } else {
                    left++;
                }
            } else {
                if (right == arr.length - 1) {
                    return arr[left];
                } else {
                    right++;
                }
            }
        }

        List<Integer> list = Arrays.asList(1, 2, 3, 4);
        list.remove(0);
        return 0;
    }
}
