package org.example;

import org.junit.jupiter.api.Test;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;

class BoundedSumTest {

    @Test
    void test10x10() throws InterruptedException {
        BoundedSum bs = new BoundedSum();

        ExecutorService producer = Executors.newFixedThreadPool(10);
        for (int i = 0; i < 10; i++) {
            producer.execute(() -> {
                try {
                    bs.add(1);
                    System.out.println(Thread.currentThread().getName());
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            });

        }


        ExecutorService consumer = Executors.newFixedThreadPool(10);

        for (int i = 0; i < 10; i++) {
            consumer.execute(() -> {
                try {
                    System.out.println(Thread.currentThread().getName());
                    int sum = bs.getSumAndClear();
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            });
        }
        producer.shutdown();
        consumer.shutdown();
        producer.awaitTermination(1, TimeUnit.SECONDS);
        consumer.awaitTermination(1, TimeUnit.SECONDS);

        assertEquals(0, bs.getSumAndClear());

    }
}