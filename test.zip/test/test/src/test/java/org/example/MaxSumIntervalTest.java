package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class MaxSumIntervalTest {

    @Test
    void testEmpty() {

    }

    @Test
    void testNull() {

    }

    @Test
    void test2() {
        assertEquals(1, MaxSumInterval.calc(new Integer[]{2, -1}));
    }

    @Test
    void test3() {
        assertEquals(6, MaxSumInterval.calc(new Integer[]{2, 1, -5}));
    }

    @Test
    void test4() {
        assertEquals(6, MaxSumInterval.calc(new Integer[]{-4, 2, 1, -5}));
    }

    @Test
    void test10() {
        assertEquals(30, MaxSumInterval.calc(new Integer[]{-5, 1, 1, -5, 5, 5, -5, 1, 1, 1, -5, -5}));
    }
}
