package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AnagramDetectorTest {


    @Test
    void isStrongAnagramTrue () {
        assertTrue(AnagramDetector.isAnagram("qwertyuiop", "erqwtpuiyo"));
    }

    @Test
    void isAnagramTrue () {
        assertTrue(AnagramDetector.isAnagram("aba", "baa"));
    }

    @Test
    void isAnagramFalse () {
        assertFalse(AnagramDetector.isAnagram("aba", "caa"));
    }

    @Test
    void firstIncludeSecond () {
        assertFalse(AnagramDetector.isAnagram("aba", "cabac"));
    }

    @Test
    void bothEmpty () {
        assertFalse(AnagramDetector.isAnagram("", ""));
    }

    @Test
    void bothNull () {
        assertFalse(AnagramDetector.isAnagram(null, null));
    }

    @Test
    void nullEmpty () {
        assertFalse(AnagramDetector.isAnagram(null, ""));
    }

}