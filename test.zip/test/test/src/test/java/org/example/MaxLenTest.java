package org.example;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;


public class MaxLenTest {

    @Test
    public void emptyArrTest() {
        assertEquals(0, MaxLen.getMax(new int[]{}));
    }

    @Test
    public void onlyZeroTest() {
        assertEquals(0, MaxLen.getMax(new int[]{0,0,0,0,0,0}));
    }

    @Test
    public void testWithValue2Success() {
        assertEquals(2, MaxLen.getMax(new int[]{0,0,0,1,1,0}));
    }

    @Test
    public void testWithValue2Fail() {
        assertNotEquals(2 , MaxLen.getMax(new int[]{0,0,1,1,1,0}));
    }

    @Test
    public void testWithValue2Chain() {
        assertEquals(2 , MaxLen.getMax(new int[]{1,1,0,1,0,0}));
    }

    @Test
    public void testWithValue5() {
        assertEquals(5, MaxLen.getMax(new int[]{0,0,1,1,1,1,1,0}));
    }

    @Test
    public void testOnly1Values() {
        int[] arr = new int[]{1,1,1,1,1,1,1,1};
        assertEquals(arr.length, MaxLen.getMax(arr));
    }



}
