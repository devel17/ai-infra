package org.example;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class CountingSortTest {

    Sortable sorter = new CountingSort();

    @Test
    void sortNoElem() {
        assertArrayEquals(sorter.sort(new int[]{}), new int[]{});
    }

    @Test
    void sortNull() {
        assertNull(sorter.sort(null));
    }

    @Test
    void sortOneElem() {
        assertArrayEquals(sorter.sort(new int[]{1}), new int[]{1});
    }

    @Test
    void sortTwoElemNoSortred() {
        assertArrayEquals(sorter.sort(new int[]{2, 1}), new int[]{1, 2});
    }

    @Test
    void sortTwoElemSortred() {
        assertArrayEquals(sorter.sort(new int[]{1, 2}), new int[]{1, 2});
    }

    @Test
    void sortThreeElementSortreed() {
        assertArrayEquals(sorter.sort(new int[]{1, 2, 3}), new int[]{1, 2, 3});
    }

    @Test
    void sortThreeElementUnsort() {
        assertArrayEquals(sorter.sort(new int[]{2, 3, 1}), new int[]{1, 2, 3});
    }

    @Test
    void sortThreeElement321() {
        assertArrayEquals(sorter.sort(new int[]{3, 2, 1}), new int[]{1, 2, 3});
    }

    @Test
    void sortThreeElement132() {
        assertArrayEquals(sorter.sort(new int[]{1, 3, 2}), new int[]{1, 2, 3});
    }

    @Test
    void sortThreeElementHeavy() {
        assertArrayEquals(sorter.sort(new int[]{64, 34, 25, 12, 22, 11, 90}), new int[]{11, 12, 22, 25, 34, 64, 90});
    }

    @Test
    void sortThreeElementDinymicHeavy() {
        Random rand = new Random();
        int[] testArr = new int[100];
        for (int i = 0; i < testArr.length; i++) {
            testArr[i] = rand.nextInt(10);
        }
        int[] sortedArr = Arrays.copyOf(testArr, testArr.length);
        Arrays.sort(sortedArr);

        assertArrayEquals(sortedArr, sorter.sort(testArr));
    }
}