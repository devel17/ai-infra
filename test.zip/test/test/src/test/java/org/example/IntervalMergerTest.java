package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

class IntervalMergerTest {

    @Test
    void mergeNullTest() {
        int[][] matrixActual = new int[][]{{2, 8}, {1, 10}};
        int[][] matrixExpected = new int[][]{{1, 10}};
        assertArrayEquals(IntervalMerger.merge(null), new int[0][0]);
    }

    @Test
    void mergeEmptyTest() {
        int[][] matrixActual = new int[][]{};
        int[][] matrixExpected = new int[][]{};
        assertArrayEquals(IntervalMerger.merge(matrixActual), matrixExpected);
    }

    @Test
    void noMerge2Test() {
        int[][] matrixActual = new int[][]{{3, 4}, {1, 2}};
        int[][] matrixExpected = new int[][]{{1, 2}, {3, 4}};
        assertArrayEquals(IntervalMerger.merge(matrixActual), matrixExpected);
    }

    @Test
    void fullMerge2Test() {
        int[][] matrixActual = new int[][]{{2, 8}, {1, 10}};
        int[][] matrixExpected = new int[][]{{1, 10}};
        assertArrayEquals(IntervalMerger.merge(matrixActual), matrixExpected);
    }

    @Test
    void crossMerge2Test() {
        int[][] matrixActual = new int[][]{{1, 5}, {5, 10}};
        int[][] matrixExpected = new int[][]{{1, 10}};
        assertArrayEquals(IntervalMerger.merge(matrixActual), matrixExpected);
    }
}