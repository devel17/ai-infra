package org.example;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class MergeSortTest {

    Sortable sorter = new MergeSort();

    @Test
    void sortNull() {
        assertNull(sorter.sort(null));
    }

    @Test
    void sortNoElement() {
        assertArrayEquals(sorter.sort(new int[]{}), new int[]{});
    }

    @Test
    void sortOneElement() {
        assertArrayEquals(sorter.sort(new int[]{1}), new int[]{1});
    }

    @Test
    void sortTwoSortedElement() {
        assertArrayEquals(sorter.sort(new int[]{1, 2}), new int[]{1, 2});
    }

    @Test
    void sortTwoUnSortedElement() {
        assertArrayEquals(sorter.sort(new int[]{2, 1}), new int[]{1, 2});
    }

    @Test
    void sortThreeElementSortreed() {
        assertArrayEquals(sorter.sort(new int[]{1, 2, 3}), new int[]{1, 2, 3});
    }

    @Test
    void sortThreeElementHeavy() {
        Random rand = new Random();
        int[] testArr = new int[10];
        for (int i = 0; i < testArr.length; i++) {
            testArr[i] = rand.nextInt(10);
        }
        int[] sortedArr = Arrays.copyOf(testArr, testArr.length);
        Arrays.sort(sortedArr);

        assertArrayEquals(sortedArr, sorter.sort(testArr));
    }

}