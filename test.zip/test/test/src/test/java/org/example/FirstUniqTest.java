package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FirstUniqTest {

    @Test
    void testNull() {
        assertEquals(0, FirstUniq.getFirst(null));
    }

    @Test
    void testEmpty() {
        assertEquals(0, FirstUniq.getFirst(new int[]{}));
    }

    @Test
    void test2() {
        assertEquals(9, FirstUniq.getFirst(new int[]{9, 4}));
    }

    @Test
    void test2TheSame() {
        assertEquals(0, FirstUniq.getFirst(new int[]{9, 9}));
    }

    @Test
    void test3() {
        assertEquals(4, FirstUniq.getFirst(new int[]{9, 4, 9}));
    }

    @Test
    void test31() {
        assertEquals(4, FirstUniq.getFirst(new int[]{9, 9, 4}));
    }
}