package org.example;

import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Timeout;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;

class CounterTest {


    @RepeatedTest(10)
    @Timeout(value = 1, unit = TimeUnit.SECONDS)
    void test50() throws InterruptedException {
        Counter c = new Counter();
//        CountDownLatch cd = new CountDownLatch(200);
        ExecutorService ex = Executors.newVirtualThreadPerTaskExecutor();

        for (int i = 0; i < 200; i++) {
            ex.submit(() -> {
                c.increment();
//                cd.countDown();
            });
        }

//        cd.await();
        ex.shutdown();

        ex.awaitTermination(1, TimeUnit.SECONDS);

        assertEquals(100, c.getCount());
    }

}