package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

class QuickSortTest {

    QuickSort sorter = new QuickSort();

    @Test
    void sortNoElem() {
        assertNull(sorter.sort(new int[]{}));
    }

    @Test
    void sortNull() {
        assertNull(sorter.sort(null));
    }

    @Test
    void sortOneElem() {
        assertArrayEquals(sorter.sort(new int[]{1}), new int[]{1});
    }

    @Test
    void sortTwoElemNoSortred() {
        assertArrayEquals(sorter.sort(new int[]{2, 1}), new int[]{1, 2});
    }

    @Test
    void sortTwoElemSortred() {
        assertArrayEquals(sorter.sort(new int[]{1, 2}), new int[]{1, 2});
    }

    @Test
    void sortThreeElementSortreed() {
        assertArrayEquals(sorter.sort(new int[]{1, 2, 3}), new int[]{1, 2, 3});
    }

    @Test
    void sortThreeElementUnsort() {
        assertArrayEquals(sorter.sort(new int[]{2, 3, 1}), new int[]{1, 2, 3});
    }

    @Test
    void sortThreeElement321() {
        assertArrayEquals(sorter.sort(new int[]{3, 2, 1}), new int[]{1, 2, 3});
    }

    @Test
    void sortThreeElement132() {
        assertArrayEquals(sorter.sort(new int[]{1, 3, 2}), new int[]{1, 2, 3});
    }

    @Test
    void sortThreeElementHeavy() {
        assertArrayEquals(sorter.sort(new int[]{64, 34, 25, 12, 22, 11, 90}), new int[]{11, 12, 22, 25, 34, 64, 90});
    }

}